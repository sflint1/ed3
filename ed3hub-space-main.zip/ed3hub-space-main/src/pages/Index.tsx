
import { ArrowRight, CheckCircle, Star, Users, Zap, Shield, Globe, Mail, Phone, MapPin, Calendar, Bell, Coins, BookOpen, Trophy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-blue-50 to-blue-100">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-blue-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="text-2xl font-bold text-blue-600">
              ed3hub
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#about" className="text-blue-600 hover:text-blue-800 transition-colors">About</a>
              <a href="#space" className="text-blue-600 hover:text-blue-800 transition-colors">Twitter Space</a>
              <a href="#features" className="text-blue-600 hover:text-blue-800 transition-colors">Features</a>
            </div>
            <Button 
              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white"
              onClick={() => window.open('https://x.com/ed3hub/status/1900941077529420237?t=Fana3YZxWHaRDAU_e8yAmA&s=19', '_blank')}
            >
              Join Platform
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-fade-in">
            <h1 className="text-5xl md:text-7xl font-bold text-blue-900 mb-6 leading-tight">
              Learn. Earn.
              <span className="bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent"> Evolve.</span>
            </h1>
            <p className="text-xl md:text-2xl text-blue-700 mb-8 max-w-3xl mx-auto leading-relaxed">
              ed3hub is the revolutionary Web3 learn-to-earn platform where education meets blockchain innovation. Master new skills while earning crypto rewards.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-lg px-8 py-4 text-white"
                onClick={() => window.open('https://x.com/i/spaces/1OwGWXWyRnpJQ', '_blank')}
              >
                Join Space
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white text-lg px-8 py-4"
                onClick={() => window.open('https://wa.link/1yd66i', '_blank')}
              >
                Remind Me of the Space
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Twitter Space Highlight */}
      <section id="space" className="py-20 px-4 bg-gradient-to-r from-blue-500 to-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <div className="inline-flex items-center bg-white/20 rounded-full px-6 py-2 text-white mb-4">
              <Calendar className="h-4 w-4 mr-2" />
              Special Event - June 26th
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Join Our Exclusive Twitter Space
            </h2>
            <div className="text-xl text-white/90 mb-6 leading-relaxed">
              <p className="mb-4">
                Don't miss our upcoming Twitter Space on June 26th! Join industry leaders, educators, and Web3 enthusiasts as we discuss the future of learn-to-earn platforms and blockchain education.
              </p>
              <div className="bg-white/10 rounded-lg p-6 mb-4">
                <p className="font-semibold mb-2">Not a trader? Not a problem.</p>
                <p className="mb-2">ed3hub's first X-Space is your gateway to real skills, real stories, and real ways to earn in Web3, no charts and candles needed.</p>
                <p className="font-medium">Tune in. Connect. Start your journey.</p>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-blue-600 hover:bg-white/90 text-lg px-8 py-4 font-semibold"
              onClick={() => window.open('https://x.com/i/spaces/1OwGWXWyRnpJQ', '_blank')}
            >
              <Calendar className="mr-2 h-5 w-5" />
              Add to Calendar
            </Button>
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white text-lg px-8 py-4"
              onClick={() => window.open('https://wa.link/1yd66i', '_blank')}
            >
              <Bell className="mr-2 h-5 w-5" />
              Remind Me of This Space
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-6">
              Why ed3hub?
            </h2>
            <p className="text-xl text-blue-700 max-w-3xl mx-auto">
              Experience the future of education where learning is rewarded with real value
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="group hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Coins className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-blue-900 mb-4">Earn While You Learn</h3>
                <p className="text-blue-700 leading-relaxed">
                  Complete courses, pass assessments, and earn cryptocurrency rewards. Your education investment pays dividends immediately.
                </p>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <BookOpen className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-blue-900 mb-4">Web3 Focused</h3>
                <p className="text-blue-700 leading-relaxed">
                  Master blockchain, DeFi, NFTs, smart contracts, and other cutting-edge technologies that are shaping the digital future.
                </p>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Trophy className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-blue-900 mb-4">Achievement Rewards</h3>
                <p className="text-blue-700 leading-relaxed">
                  Unlock badges, certificates, and exclusive NFTs as you progress. Build a verifiable portfolio of your Web3 expertise.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-blue-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-6">
              Platform Features
            </h2>
            <p className="text-xl text-blue-700 max-w-3xl mx-auto">
              Everything you need to succeed in the Web3 ecosystem
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <Zap className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-blue-900 mb-2">Interactive Learning</h3>
              <p className="text-blue-700">Hands-on tutorials and real-world projects that prepare you for the Web3 industry.</p>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <Shield className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-blue-900 mb-2">Secure Wallet Integration</h3>
              <p className="text-blue-700">Connect your wallet securely and receive rewards directly to your preferred address.</p>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <Users className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-blue-900 mb-2">Community Learning</h3>
              <p className="text-blue-700">Join study groups, participate in discussions, and learn from industry experts.</p>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <Globe className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-blue-900 mb-2">Global Access</h3>
              <p className="text-blue-700">Learn from anywhere in the world with our decentralized platform architecture.</p>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <CheckCircle className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-blue-900 mb-2">Verified Certificates</h3>
              <p className="text-blue-700">Earn blockchain-verified certificates that employers trust and recognize.</p>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <Star className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-blue-900 mb-2">Expert Instructors</h3>
              <p className="text-blue-700">Learn from industry pioneers and successful Web3 entrepreneurs.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-blue-500 to-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Start Your Web3 Journey?
          </h2>
          <div className="text-xl text-white/90 mb-8 leading-relaxed">
            <p className="mb-4">
              Join ed3hub today and be part of the revolution where education meets earning potential
            </p>
            <div className="bg-white/10 rounded-lg p-6 mb-4">
              <p className="font-semibold mb-2">Not a trader? Not a problem.</p>
              <p className="mb-2">ed3hub's first X-Space is your gateway to real skills, real stories, and real ways to earn in Web3, no charts and candles needed.</p>
              <p className="font-medium">Tune in. Connect. Start your journey.</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-blue-600 hover:bg-white/90 text-lg px-8 py-4"
              onClick={() => window.open('https://x.com/i/spaces/1OwGWXWyRnpJQ', '_blank')}
            >
              Join Space Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white text-lg px-8 py-4"
              onClick={() => window.open('https://x.com/i/spaces/1OwGWXWyRnpJQ', '_blank')}
            >
              Remind me of the space
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-blue-900">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-2xl font-bold text-white mb-4 md:mb-0">
              ed3hub
            </div>
            <div className="text-blue-200 text-center md:text-right">
              © 2024 ed3hub. Empowering the future of Web3 education.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
